# TIRVEXA V5 — Publication + vrai multijoueur

Version préparée pour le déploiement avec Node.js, Express, PostgreSQL et Socket.IO.

## Multijoueur intégré
- Matchmaking réel 4v4 (8 joueurs par salle)
- File d'attente serveur
- Attribution automatique des équipes
- Salle d'attente et bouton « Je suis prêt »
- Démarrage synchronisé de la partie
- Événements temps réel : tirs, déplacements et scores
- Déconnexion retirée automatiquement de la file/salle

Socket.IO fournit une communication bidirectionnelle temps réel et peut utiliser WebSocket avec reconnexion automatique. Voir https://socket.io/.

## Variables d'environnement
- `DATABASE_URL` : URL PostgreSQL
- `JWT_SECRET` : secret long et aléatoire
- `PORT` : fourni automatiquement par l'hébergeur

## Lancer
```bash
npm install
npm start
```

## Déploiement
Créer un service Node/Express et une base PostgreSQL, puis définir `DATABASE_URL` et `JWT_SECRET`.

Important : cette version met en place l'infrastructure multijoueur réelle, mais le gameplay FPS complet (physique, collision, anti-triche, interpolation, hitboxes, matchmaking régional, etc.) demande encore du développement avant une publication commerciale.
